select s.Lyricist_id,a.Name,count(s.Song_id) as num_songs_written
from song as s,artist as a
where s.Lyricist_id=a.artist_id
group by s.Lyricist_id,a.Name
having num_songs_written>= ALL(select count(s1.Song_id) as num_songs_written
from Song as s1,artist as a1
where s1.Lyricist_id=a1.artist_id
group by s1.Lyricist_id,a1.Name);