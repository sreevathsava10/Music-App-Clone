select s.Name,c1.Name
from Song as s,Artist as c,Artist as c1
where s.composer_id=c.Artist_id and c.Name="The Chainsmokers" and s.singer_id=c1.Artist_id;