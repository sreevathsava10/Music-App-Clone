select Year,count(*) as cnt
from song
where Album_id IS NULL
group by Year
having cnt>=ALL(select count(*) as cnt from song where Album_id IS NULL group by Year);