select d.name
from song as s,album as d,artist as a
where s.Album_id=d.Album_id and a.Gender='F' and s.Singer_id=a.artist_id and d.name not in (select d1.name
from song as s1,album as d1,artist as a1
where s1.Album_id=d1.Album_id and a1.Gender='M' and s1.Singer_id=a1.artist_id)
group by d.name;