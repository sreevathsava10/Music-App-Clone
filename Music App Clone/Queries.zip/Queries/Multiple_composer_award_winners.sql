select c.artist_id,c.name,count(*) as No_composer_awards
from best_artist as b,artist as c
where b.category="Composer" and b.Artist_id=c.artist_id
group by c.name
having count(*)>2