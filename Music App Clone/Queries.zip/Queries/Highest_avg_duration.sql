select Year, AVG(Duration) as avg_dur
from song
group by Year
having avg_dur>= ALL(select AVG(Duration) as avg_dur
from song
group by Year);